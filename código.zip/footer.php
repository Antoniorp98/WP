<embed src="http://localhost/wordpress/wp-content/uploads/2019/02/MV-에이식스피-페이스오프-A6P-Face-Off.mp3" autostarty="true" loop="true" volume="80" width="0" height="0"></embed>
<footer class="main-footer">
		<div class="container">
			<div class="f_center">
				<p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></p>
			</div>
			<!-- <div class="f_right">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="#">Services</a></li>
				</ul>
			</div> -->

		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>