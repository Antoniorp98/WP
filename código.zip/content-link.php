<article class="post post-link">
	<div class="well">
		<a href="<?php echo get_the_content(); ?>"><?php echo the_title(); ?></a>
	</div>
</article>